package net.mcreator.bombeaddons.item;

import net.minecraft.world.item.Item;

public class NucleaireItem extends Item {
	public NucleaireItem(Item.Properties properties) {
		super(properties);
	}
}