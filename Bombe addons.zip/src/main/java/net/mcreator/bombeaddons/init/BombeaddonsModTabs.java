/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.bombeaddons.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.bombeaddons.BombeaddonsMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class BombeaddonsModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, BombeaddonsMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.REDSTONE_BLOCKS) {
			tabData.accept(BombeaddonsModBlocks.SATANBOMBA_N.get().asItem());
			tabData.accept(BombeaddonsModBlocks.TN_TWHITE.get().asItem());
			tabData.accept(BombeaddonsModBlocks.TNTGREEN.get().asItem());
			tabData.accept(BombeaddonsModBlocks.TNT_SOUFFLE.get().asItem());
			tabData.accept(BombeaddonsModItems.RADIOACTIF_BUCKET.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(BombeaddonsModBlocks.RADIOACTIFF_LOG.get().asItem());
			tabData.accept(BombeaddonsModBlocks.RADIOACTIFF_WOOD.get().asItem());
			tabData.accept(BombeaddonsModBlocks.RADIOACTIFF_PLANKS.get().asItem());
			tabData.accept(BombeaddonsModBlocks.RADIOACTIFF_STAIRS.get().asItem());
			tabData.accept(BombeaddonsModBlocks.RADIOACTIFF_SLAB.get().asItem());
			tabData.accept(BombeaddonsModBlocks.RADIOACTIFF_FENCE.get().asItem());
			tabData.accept(BombeaddonsModBlocks.RADIOACTIFF_FENCE_GATE.get().asItem());
			tabData.accept(BombeaddonsModBlocks.RADIOACTIFF_PRESSURE_PLATE.get().asItem());
			tabData.accept(BombeaddonsModBlocks.RADIOACTIFF_BUTTON.get().asItem());
			tabData.accept(BombeaddonsModBlocks.NUCLEAIRE_ORE.get().asItem());
			tabData.accept(BombeaddonsModBlocks.NUCLEAIRE_BLOCK.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(BombeaddonsModBlocks.RADIOACTIFF_LEAVES.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {
			tabData.accept(BombeaddonsModItems.NUCLEAIRE.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(BombeaddonsModItems.COMBIENAISONNUCLEAIRE_ARMOR_HELMET.get());
			tabData.accept(BombeaddonsModItems.COMBIENAISONNUCLEAIRE_ARMOR_CHESTPLATE.get());
			tabData.accept(BombeaddonsModItems.COMBIENAISONNUCLEAIRE_ARMOR_LEGGINGS.get());
			tabData.accept(BombeaddonsModItems.COMBIENAISONNUCLEAIRE_ARMOR_BOOTS.get());
			tabData.accept(BombeaddonsModItems.OUTILS_NUCLEAIRE_SWORD.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(BombeaddonsModItems.OUTILS_NUCLEAIRE_PICKAXE.get());
			tabData.accept(BombeaddonsModItems.OUTILS_NUCLEAIRE_AXE.get());
			tabData.accept(BombeaddonsModItems.OUTILS_NUCLEAIRE_SHOVEL.get());
			tabData.accept(BombeaddonsModItems.OUTILS_NUCLEAIRE_HOE.get());
		}
	}
}