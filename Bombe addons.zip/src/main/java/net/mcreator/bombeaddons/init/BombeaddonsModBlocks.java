/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.bombeaddons.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

import net.mcreator.bombeaddons.block.TntgreenBlock;
import net.mcreator.bombeaddons.block.TNTwhiteBlock;
import net.mcreator.bombeaddons.block.TNTSouffleBlock;
import net.mcreator.bombeaddons.block.SatanbombaNBlock;
import net.mcreator.bombeaddons.block.RadioactiffWoodBlock;
import net.mcreator.bombeaddons.block.RadioactiffStairsBlock;
import net.mcreator.bombeaddons.block.RadioactiffSlabBlock;
import net.mcreator.bombeaddons.block.RadioactiffPressurePlateBlock;
import net.mcreator.bombeaddons.block.RadioactiffPlanksBlock;
import net.mcreator.bombeaddons.block.RadioactiffLogBlock;
import net.mcreator.bombeaddons.block.RadioactiffLeavesBlock;
import net.mcreator.bombeaddons.block.RadioactiffFenceGateBlock;
import net.mcreator.bombeaddons.block.RadioactiffFenceBlock;
import net.mcreator.bombeaddons.block.RadioactiffButtonBlock;
import net.mcreator.bombeaddons.block.RadioactifBlock;
import net.mcreator.bombeaddons.block.NucleaireOreBlock;
import net.mcreator.bombeaddons.block.NucleaireBlockBlock;
import net.mcreator.bombeaddons.BombeaddonsMod;

import java.util.function.Function;

public class BombeaddonsModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(BombeaddonsMod.MODID);
	public static final DeferredBlock<Block> SATANBOMBA_N = register("satanbomba_n", SatanbombaNBlock::new);
	public static final DeferredBlock<Block> TN_TWHITE = register("tn_twhite", TNTwhiteBlock::new);
	public static final DeferredBlock<Block> TNTGREEN = register("tntgreen", TntgreenBlock::new);
	public static final DeferredBlock<Block> TNT_SOUFFLE = register("tnt_souffle", TNTSouffleBlock::new);
	public static final DeferredBlock<Block> RADIOACTIF = register("radioactif", RadioactifBlock::new);
	public static final DeferredBlock<Block> RADIOACTIFF_LOG = register("radioactiff_log", RadioactiffLogBlock::new);
	public static final DeferredBlock<Block> RADIOACTIFF_WOOD = register("radioactiff_wood", RadioactiffWoodBlock::new);
	public static final DeferredBlock<Block> RADIOACTIFF_PLANKS = register("radioactiff_planks", RadioactiffPlanksBlock::new);
	public static final DeferredBlock<Block> RADIOACTIFF_LEAVES = register("radioactiff_leaves", RadioactiffLeavesBlock::new);
	public static final DeferredBlock<Block> RADIOACTIFF_STAIRS = register("radioactiff_stairs", RadioactiffStairsBlock::new);
	public static final DeferredBlock<Block> RADIOACTIFF_SLAB = register("radioactiff_slab", RadioactiffSlabBlock::new);
	public static final DeferredBlock<Block> RADIOACTIFF_FENCE = register("radioactiff_fence", RadioactiffFenceBlock::new);
	public static final DeferredBlock<Block> RADIOACTIFF_FENCE_GATE = register("radioactiff_fence_gate", RadioactiffFenceGateBlock::new);
	public static final DeferredBlock<Block> RADIOACTIFF_PRESSURE_PLATE = register("radioactiff_pressure_plate", RadioactiffPressurePlateBlock::new);
	public static final DeferredBlock<Block> RADIOACTIFF_BUTTON = register("radioactiff_button", RadioactiffButtonBlock::new);
	public static final DeferredBlock<Block> NUCLEAIRE_ORE = register("nucleaire_ore", NucleaireOreBlock::new);
	public static final DeferredBlock<Block> NUCLEAIRE_BLOCK = register("nucleaire_block", NucleaireBlockBlock::new);

	// Start of user code block custom blocks
	// End of user code block custom blocks
	private static <B extends Block> DeferredBlock<B> register(String name, Function<BlockBehaviour.Properties, ? extends B> supplier) {
		return REGISTRY.registerBlock(name, supplier, BlockBehaviour.Properties.of());
	}
}