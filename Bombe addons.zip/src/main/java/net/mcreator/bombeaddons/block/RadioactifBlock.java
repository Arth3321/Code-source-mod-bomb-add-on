package net.mcreator.bombeaddons.block;

import net.minecraft.world.level.material.PushReaction;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.LiquidBlock;

import net.mcreator.bombeaddons.init.BombeaddonsModFluids;

public class RadioactifBlock extends LiquidBlock {
	public RadioactifBlock(BlockBehaviour.Properties properties) {
		super(BombeaddonsModFluids.RADIOACTIF.get(), properties.mapColor(MapColor.WATER).strength(100f).noCollission().noLootTable().liquid().pushReaction(PushReaction.DESTROY).sound(SoundType.EMPTY).replaceable());
	}
}