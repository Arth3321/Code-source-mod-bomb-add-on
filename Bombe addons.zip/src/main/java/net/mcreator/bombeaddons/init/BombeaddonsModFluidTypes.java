/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.bombeaddons.init;

import net.neoforged.neoforge.registries.NeoForgeRegistries;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.fluids.FluidType;

import net.mcreator.bombeaddons.fluid.types.RadioactifFluidType;
import net.mcreator.bombeaddons.BombeaddonsMod;

public class BombeaddonsModFluidTypes {
	public static final DeferredRegister<FluidType> REGISTRY = DeferredRegister.create(NeoForgeRegistries.FLUID_TYPES, BombeaddonsMod.MODID);
	public static final DeferredHolder<FluidType, FluidType> RADIOACTIF_TYPE = REGISTRY.register("radioactif", () -> new RadioactifFluidType());
}