/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.bombeaddons.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.bombeaddons.item.RadioactifItem;
import net.mcreator.bombeaddons.item.Outils_nucleaireSwordItem;
import net.mcreator.bombeaddons.item.Outils_nucleaireShovelItem;
import net.mcreator.bombeaddons.item.Outils_nucleairePickaxeItem;
import net.mcreator.bombeaddons.item.Outils_nucleaireHoeItem;
import net.mcreator.bombeaddons.item.Outils_nucleaireAxeItem;
import net.mcreator.bombeaddons.item.NucleaireItem;
import net.mcreator.bombeaddons.item.CombienaisonnucleaireArmorItem;
import net.mcreator.bombeaddons.BombeaddonsMod;

import java.util.function.Function;

public class BombeaddonsModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(BombeaddonsMod.MODID);
	public static final DeferredItem<Item> SATANBOMBA_N = block(BombeaddonsModBlocks.SATANBOMBA_N, new Item.Properties().stacksTo(99));
	public static final DeferredItem<Item> TN_TWHITE = block(BombeaddonsModBlocks.TN_TWHITE);
	public static final DeferredItem<Item> TNTGREEN = block(BombeaddonsModBlocks.TNTGREEN);
	public static final DeferredItem<Item> TNT_SOUFFLE = block(BombeaddonsModBlocks.TNT_SOUFFLE);
	public static final DeferredItem<Item> RADIOACTIF_BUCKET = register("radioactif_bucket", RadioactifItem::new);
	public static final DeferredItem<Item> RADIOACTIFF_LOG = block(BombeaddonsModBlocks.RADIOACTIFF_LOG);
	public static final DeferredItem<Item> RADIOACTIFF_WOOD = block(BombeaddonsModBlocks.RADIOACTIFF_WOOD);
	public static final DeferredItem<Item> RADIOACTIFF_PLANKS = block(BombeaddonsModBlocks.RADIOACTIFF_PLANKS);
	public static final DeferredItem<Item> RADIOACTIFF_LEAVES = block(BombeaddonsModBlocks.RADIOACTIFF_LEAVES);
	public static final DeferredItem<Item> RADIOACTIFF_STAIRS = block(BombeaddonsModBlocks.RADIOACTIFF_STAIRS);
	public static final DeferredItem<Item> RADIOACTIFF_SLAB = block(BombeaddonsModBlocks.RADIOACTIFF_SLAB);
	public static final DeferredItem<Item> RADIOACTIFF_FENCE = block(BombeaddonsModBlocks.RADIOACTIFF_FENCE);
	public static final DeferredItem<Item> RADIOACTIFF_FENCE_GATE = block(BombeaddonsModBlocks.RADIOACTIFF_FENCE_GATE);
	public static final DeferredItem<Item> RADIOACTIFF_PRESSURE_PLATE = block(BombeaddonsModBlocks.RADIOACTIFF_PRESSURE_PLATE);
	public static final DeferredItem<Item> RADIOACTIFF_BUTTON = block(BombeaddonsModBlocks.RADIOACTIFF_BUTTON);
	public static final DeferredItem<Item> NUCLEAIRE = register("nucleaire", NucleaireItem::new);
	public static final DeferredItem<Item> NUCLEAIRE_ORE = block(BombeaddonsModBlocks.NUCLEAIRE_ORE);
	public static final DeferredItem<Item> NUCLEAIRE_BLOCK = block(BombeaddonsModBlocks.NUCLEAIRE_BLOCK);
	public static final DeferredItem<Item> COMBIENAISONNUCLEAIRE_ARMOR_HELMET = register("combienaisonnucleaire_armor_helmet", CombienaisonnucleaireArmorItem.Helmet::new);
	public static final DeferredItem<Item> COMBIENAISONNUCLEAIRE_ARMOR_CHESTPLATE = register("combienaisonnucleaire_armor_chestplate", CombienaisonnucleaireArmorItem.Chestplate::new);
	public static final DeferredItem<Item> COMBIENAISONNUCLEAIRE_ARMOR_LEGGINGS = register("combienaisonnucleaire_armor_leggings", CombienaisonnucleaireArmorItem.Leggings::new);
	public static final DeferredItem<Item> COMBIENAISONNUCLEAIRE_ARMOR_BOOTS = register("combienaisonnucleaire_armor_boots", CombienaisonnucleaireArmorItem.Boots::new);
	public static final DeferredItem<Item> OUTILS_NUCLEAIRE_PICKAXE = register("outils_nucleaire_pickaxe", Outils_nucleairePickaxeItem::new);
	public static final DeferredItem<Item> OUTILS_NUCLEAIRE_AXE = register("outils_nucleaire_axe", Outils_nucleaireAxeItem::new);
	public static final DeferredItem<Item> OUTILS_NUCLEAIRE_SWORD = register("outils_nucleaire_sword", Outils_nucleaireSwordItem::new);
	public static final DeferredItem<Item> OUTILS_NUCLEAIRE_SHOVEL = register("outils_nucleaire_shovel", Outils_nucleaireShovelItem::new);
	public static final DeferredItem<Item> OUTILS_NUCLEAIRE_HOE = register("outils_nucleaire_hoe", Outils_nucleaireHoeItem::new);

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}