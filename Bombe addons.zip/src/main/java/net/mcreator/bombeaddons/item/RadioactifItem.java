package net.mcreator.bombeaddons.item;

import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BucketItem;

import net.mcreator.bombeaddons.init.BombeaddonsModFluids;

public class RadioactifItem extends BucketItem {
	public RadioactifItem(Item.Properties properties) {
		super(BombeaddonsModFluids.RADIOACTIF.get(), properties.craftRemainder(Items.BUCKET).stacksTo(1)

		);
	}
}