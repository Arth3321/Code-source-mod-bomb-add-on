package net.mcreator.bombeaddons.fluid;

import net.neoforged.neoforge.fluids.BaseFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.ParticleOptions;

import net.mcreator.bombeaddons.init.BombeaddonsModItems;
import net.mcreator.bombeaddons.init.BombeaddonsModFluids;
import net.mcreator.bombeaddons.init.BombeaddonsModFluidTypes;
import net.mcreator.bombeaddons.init.BombeaddonsModBlocks;

public abstract class RadioactifFluid extends BaseFlowingFluid {
	public static final BaseFlowingFluid.Properties PROPERTIES = new BaseFlowingFluid.Properties(() -> BombeaddonsModFluidTypes.RADIOACTIF_TYPE.get(), () -> BombeaddonsModFluids.RADIOACTIF.get(), () -> BombeaddonsModFluids.FLOWING_RADIOACTIF.get())
			.explosionResistance(100f).tickRate(10).slopeFindDistance(15).bucket(() -> BombeaddonsModItems.RADIOACTIF_BUCKET.get()).block(() -> (LiquidBlock) BombeaddonsModBlocks.RADIOACTIF.get());

	private RadioactifFluid() {
		super(PROPERTIES);
	}

	@Override
	public ParticleOptions getDripParticle() {
		return ParticleTypes.ASH;
	}

	public static class Source extends RadioactifFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends RadioactifFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}